-- BasicCalc.hs
-- John O'Donnell

{- A basic calculator.  To compiler and run, enter these commands:
      ghc --make BasicCalc
     ./BasicCalc
 -}

module Main where

import Graphics.UI.Gtk
import Graphics.UI.Gtk.Glade
import Control.Monad
import Control.Concurrent
import Data.IORef
import Data.Maybe
import System.IO.Unsafe
import Text.Printf

{- This data structure holds the state of the system. -}

data CalcState = CalcState
  { displayString :: String  		-- what's displayed at the top
  , displayLabel :: String
  , stack :: [(Double,String)]        -- stack of numbers
  , store :: (Double, String)  		-- storage cell
  , dispEntry :: Entry       		-- the gtk Entry for the display
  , dispLabel :: Entry
  , stackBuf :: TextBuffer   		-- the gtk TextBuffer for the stack
  , isInt :: Bool
  }

{- A single state reference sr :: SR is created, which always points
to the current state of the system. -}

type SR = IORef CalcState

{- Initial state of the calculator.  The dispEntry and stackBuf fields
need to be updated with the actual gtk values, which are created
dynamically when the program is initialising itself.  The error values
given in the initState enable the program to crash with an informative
message if these fields are not initialised properly before they are
used. -}

initState :: CalcState
initState = CalcState
  { displayString = ""
  , displayLabel = ""
  , stack = [(0,"")]
  , store = (0,"")
  , dispEntry = error "Display entry not set"
  , dispLabel = error "Display label not set"
  , stackBuf = error "Stack text buffer not set"
  , isInt = True
  }

{- The main program initialises the widgets and then starts the
GUI. -}

usd2gbp :: Double
usd2gbp = 0.6252
usd2cny :: Double
usd2cny = 6.2274
usd2sgd :: Double
usd2sgd = 1.2228
usd2eur :: Double
usd2eur = 0.7738
usd2usd :: Double
usd2usd = 1.0000

main :: IO ()
main =
  do initGUI
     timeoutAddFull
       (yield >> return True)
       priorityDefaultIdle 50

-- Read in the glade file

     let gladeFilePath = "glade/calculator.glade"
     maybe_xml <- xmlNew gladeFilePath
     let xml = case maybe_xml of
           Just xml_text -> xml_text
           Nothing -> error "cannot open glade xml file"

-- Set up the main window

     mainWindow <- xmlGetWidget xml castToWindow "MainWindow"
     widgetModifyBg mainWindow StateNormal $ Color 15000 15000 15000
     onDestroy mainWindow mainQuit

-- Initialise the state reference

     sr <- newIORef initState

-- Activate Menu: File: Quit

     quitMenuAction <- xmlGetWidget xml castToMenuItem "menuQuit"
     onActivateLeaf quitMenuAction $ do mainQuit

-- Activate Help: About

     aboutDialogue <- xmlGetWidget xml castToAboutDialog "aboutDialogue"
     aboutButton <- xmlGetWidget xml castToMenuItem "menuAbout"
     onActivateLeaf aboutButton $ do widgetShow aboutDialogue
     onDestroy aboutDialogue $ do
	widgetHide aboutDialogue

     onResponse aboutDialogue $ \resp -> do 
	case resp of ResponseCancel -> (widgetHide aboutDialogue); otherwise -> return ()

-- Initialise the display entry (the top field for entering numbers)

     displayEntry <- xmlGetWidget xml castToEntry "DisplayEntry"
     displayLabel <- xmlGetWidget xml castToEntry "DisplayLabel"
     s <- readIORef sr
     writeIORef sr (s {dispEntry = displayEntry, dispLabel = displayLabel})

-- Initialise the stack view (the text view at the bottom)

     stackView <- xmlGetWidget xml castToTextView "StackTextView"
     textBufTagTable <- textTagTableNew
     stackTextBuf <- textBufferNew (Just textBufTagTable)
     textViewSetBuffer stackView stackTextBuf
     textBufferSetText stackTextBuf "\n"
     s <- readIORef sr
     writeIORef sr (s {stackBuf = stackTextBuf})

-- Set up the digit and decimal point buttons

     forM
       [("b0",'0'), ("b1",'1'), ("b2",'2'), ("b3",'3'), ("b4",'4'),
        ("b5",'5'), ("b6",'6'), ("b7",'7'), ("b8",'8'), ("b9",'9'),
        ("bpoint",'.')]
       (\(x,y) -> prepareNumButton sr xml x y)

-- Set up converter button
	{-	Array Reference
			GBP = 0
			CNY = 1
			USD = 2
			EUR = 3
			SGD = 3
	-}

-- Converter Window Bindings
     bConv <- xmlGetWidget xml castToButton "bConv"
     widgetModifyBg bConv StateNormal $ Color 40000 65535 40000
     converterWindow <- xmlGetWidget xml castToWindow "convertWindow"
     onClicked bConv $ do
	widgetShowAll converterWindow

     bCloseConv <- xmlGetWidget xml castToButton "bCloseConv"
     onClicked bCloseConv $ do
	widgetHideAll converterWindow
     onDestroy converterWindow $ do
	widgetHideAll converterWindow

-- Converts from value held in entry1 to USD and then from that value to the value held in currency 2
-- and then places the value in entry2
     bConverter <- xmlGetWidget xml castToButton "bConvert"
     onClicked bConverter $ do
	currencyFrom <- xmlGetWidget xml castToComboBox "currency1"
	currencyTo <- xmlGetWidget xml castToComboBox "currency2"
	currencyVal <- xmlGetWidget xml castToEntry "entry1"
	convVal <- xmlGetWidget xml castToEntry "entry2"
	let cur1 = unsafePerformIO $ comboBoxGetActive currencyFrom
	let cur2 = unsafePerformIO $ comboBoxGetActive currencyTo
	let curVal = unsafePerformIO $ entryGetText currencyVal
	let convertedVal = fromUSD (toUSD (read (curVal) :: Double) cur1) cur2
	entrySetText convVal $ printf "%.2f" convertedVal

-- Should hide the mod button, not working.
     bMod <- xmlGetWidget xml castToButton "bMod"
     widgetHide bMod

-- Int/Double toggle listeners

     rInt <- xmlGetWidget xml castToRadioButton "rInt"
     rDoub <- xmlGetWidget xml castToRadioButton "rDoub"
     widgetModifyBase rInt StateNormal $ Color 65000 65000 65000
     widgetModifyBase rDoub StateNormal $ Color 65000 65000 65000

     -- Show and hide buttons for different int/double modes. 
     onToggled rInt $ do
	setStack sr []
	swapMode sr
	bSin <- xmlGetWidget xml castToButton "bSin"
	bCos <- xmlGetWidget xml castToButton "bCos"
	bReciprocal <- xmlGetWidget xml castToButton "bReciprocal"
	bMod <- xmlGetWidget xml castToButton "bMod"
	bTrunc <- xmlGetWidget xml castToButton "bTrunc"
	bRound <- xmlGetWidget xml castToButton "bRound"
	bpoint <- xmlGetWidget xml castToButton "bpoint"
	bChangeSign <- xmlGetWidget xml castToButton "bChangeSign"

	widgetHide bSin
	widgetHide bCos
	widgetHide bTrunc
	widgetHide bRound
	widgetHide bpoint
	widgetHide bReciprocal
	widgetShow bMod

     onToggled rDoub $ do
	bSin <- xmlGetWidget xml castToButton "bSin"
	bCos <- xmlGetWidget xml castToButton "bCos"
	bReciprocal <- xmlGetWidget xml castToButton "bReciprocal"
	bMod <- xmlGetWidget xml castToButton "bMod"
	bTrunc <- xmlGetWidget xml castToButton "bTrunc"
	bRound <- xmlGetWidget xml castToButton "bRound"
	bpoint <- xmlGetWidget xml castToButton "bpoint"

	widgetShow bSin
	widgetShow bCos
	widgetShow bTrunc
	widgetShow bRound
	widgetShow bpoint
	widgetShow bReciprocal
	widgetHide bMod
     toggleButtonSetActive rDoub False
     toggleButtonSetActive rDoub True

-- Set up RND and TRN buttons

     bRound <- xmlGetWidget xml castToButton "bRound"
     widgetModifyBg bRound StateNormal $ Color 40000 65535 40000
     onClicked bRound $ do
	s <- readIORef sr
	let ((x,y):xs) = stack s
	setStack sr $ (((read (show (round x))::Double),"Auto Gen from RND"):xs)

     bTrunc <- xmlGetWidget xml castToButton "bTrunc"
     widgetModifyBg bTrunc StateNormal $ Color 40000 65535 40000
     onClicked bTrunc $ do
	s <- readIORef sr
	let ((x,y):xs) = stack s
	setStack sr $ (((read (show (floor x))::Double),"Auto Gen from TRN"):xs)

-- Set up the EXCH button

     bExch <- xmlGetWidget xml castToButton "bExch"
     widgetModifyBg bExch StateNormal $ Color 40000 65535 40000
     onClicked bExch $ do
	s <- readIORef sr
	let newStack = exchFunc $ stack s
	setStack sr newStack

-- Set up the STO and FET button

     bFet <- xmlGetWidget xml castToButton "bFet"
     widgetModifyBg bFet StateNormal $ Color 40000 65535 40000
     onClicked bFet $ do
	s <- readIORef sr
	let x = store s
	setStack sr $ x : (stack s)

     bSto <- xmlGetWidget xml castToButton "bSto"
     widgetModifyBg bSto StateNormal $ Color 40000 65535 40000
     onClicked bSto $ do
	s <- readIORef sr
	let (x:_) = stack s
	setStorage sr x

-- Set up the Sin, Cos and Sqrt buttons
     bSin <- xmlGetWidget xml castToButton "bSin"
     bCos <- xmlGetWidget xml castToButton "bCos"
     bSqrt <- xmlGetWidget xml castToButton "bSqrt"
     widgetModifyBg bSin StateNormal $ Color 40000 65535 40000
     widgetModifyBg bCos StateNormal $ Color 40000 65535 40000
     widgetModifyBg bSqrt StateNormal $ Color 40000 65535 40000

     onClicked bSin $ do
	s <- readIORef sr
	let ((x,y):xs) = stack s
	setStack sr $ ((sin x),y):xs

     onClicked bCos $ do
	s <- readIORef sr
	let ((x,y):xs) = stack s
	setStack sr $ ((cos x),y):xs

     onClicked bSqrt $ do
	s <- readIORef sr
	let ((x,y):xs) = stack s
	setStack sr $ ((sqrt x),y):xs

-- Set up the Enter button

     benter <- xmlGetWidget xml castToButton "benter"
     widgetModifyBg benter StateNormal $ Color 40000 65535 40000
     onClicked benter $ do
	extraText <- xmlGetWidget xml castToEntry "DisplayLabel"
     	let labelText = unsafePerformIO $ entryGetText extraText
        s <- readIORef sr
	if (show (displayString s) == "")
		then putStrLn "No value in the Display Entry"
		else do setStack sr  (((read (displayString s) :: Double),labelText) : stack s)  --Edit "" for actual message
        	     	setDisplay sr "" ""
			entrySetText (dispLabel s) ""
       
-- Set up bMod button

     bMod <- xmlGetWidget xml castToButton "bMod"
     widgetModifyBg bMod StateNormal $ Color 40000 40000 65535
     onClicked bMod $ do
	s <- readIORef sr
	setStack sr $ doMod (stack s)

-- Set up +/- button

     bChangeSign <- xmlGetWidget xml castToButton "bChangeSign"
     widgetModifyBg bChangeSign StateNormal $ Color 65535 40000 40000
     onClicked bChangeSign $ do
	s <- readIORef sr
	setStack sr $ swapSign(stack s) 

-- Set up the CLR button

     bCLR <- xmlGetWidget xml castToButton "bCLR"
     widgetModifyBg bCLR StateNormal $ Color 40000 65535 40000
     onClicked bCLR $ do
	setStack sr []
	setDisplay sr "" ""
	entrySetText (dispLabel s) ""
	
       
-- Set up the CE button

     bCE <- xmlGetWidget xml castToButton "bCE"
     widgetModifyBg bCE StateNormal $ Color 40000 65535 40000
     onClicked bCE $ do
       setDisplay sr "" ""
       entrySetText (dispLabel s) ""



-- Set up the operator buttons
     
     prepareBinopButton sr xml "bAdd" (+) "Add"
     prepareBinopButton sr xml "bSub" (-) "Sub"
     prepareBinopButton sr xml "bMul" (*) "Mul"
     prepareBinopButton sr xml "bDiv" (/) "Div"
     prepareUnopButton sr xml "bReciprocal" (1/) "RecipMod"


-- Start up the GUI
     
     widgetShowAll mainWindow
     mainGUI

-- Changes from Int mode to Double mode and vice versa.
swapMode :: SR -> IO()
swapMode sr =
	do s <- readIORef sr
	   let x = isInt s
	   writeIORef sr (s {isInt = (not x)}) 
	   putStrLn $ show $ not x

{- Set the stack to xs.  The new stack is shown in the text view on
the GUI, and is also printed to the console. -}

setStack :: SR -> [(Double,String)] -> IO ()
setStack sr xs =
  do s <- readIORef sr
     let str = show xs
     textBufferSetText (stackBuf s) (formatBufferText str sr)
     putStrLn ("Stack: " ++ str)
     writeIORef sr (s {stack = xs})

-- Formats text for output, one stack value per line.
formatBufferText :: String -> SR -> String
formatBufferText (')':']':_) _ = []
formatBufferText (']':_) _ = []
formatBufferText ('[':xs) sr = formatBufferText xs sr
formatBufferText ('(':xs) sr = formatBufferText xs sr
formatBufferText (')':',':'(':xs) sr = formatBufferText ("\n" ++ xs) sr
formatBufferText (',':xs) sr = formatBufferText ("\t" ++ xs) sr
formatBufferText (x:xs) sr =
	let s = unsafePerformIO $ readIORef sr
	in if (isInt s)
		then 
			if (x == '.') 
				then formatBufferText (skipUntilComma xs) sr
				else x: formatBufferText xs sr
		else x : formatBufferText xs sr

-- Helper method for formatBufferText
skipUntilComma :: String -> String
skipUntilComma (x:xs) =
	if (x == ',')
		then (x:xs)
		else (skipUntilComma xs)

{- Set Storage Cell -}

setStorage :: SR -> (Double,String) -> IO ()
setStorage sr x =
  do s <- readIORef sr
     writeIORef sr (s {store = x})

{- Set the display to xs.  This is set in the GUI, and also printed on
the console. -}

-- Also changes label value
setDisplay :: SR -> String -> String -> IO ()
setDisplay sr xs lab =
  do s <- readIORef sr
     entrySetText (dispEntry s) xs
     --entrySetText (dispLabel s) lab
     writeIORef sr (s {displayString = xs, displayLabel = lab})
     putStrLn $ xs ++ "\t" ++ lab

{- This function takes several parameters needed to describe an
operator with two operands, such as + or *, and it sets up the
button. -}

prepareBinopButton
  :: SR -> GladeXML -> String -> (Double -> Double -> Double) -> String -> IO ()
prepareBinopButton sr xml bname f op =
  do button <- xmlGetWidget xml castToButton bname
     widgetModifyBg button StateNormal $ Color 40000 40000 65535
     onClicked button $ do
       s <- readIORef sr
       case stack s of
         (x,x'):(y,y'):stack' ->
		if (isInt s)			-- To see if its in int mode or not, if so rounds result
		    then do let r = read (show (floor (f x y)))::Double
			    setStack sr (((r,"Auto Gen from " ++ op) ):stack')  -- Edit ... later
			    setDisplay sr (intFormat $ show r) ("Auto Gen from " ++ op)
		    else do let r = f x y
			    setStack sr (((r,"Auto Gen from " ++ op) ):stack')
			    setDisplay sr (show r)("Auto Gen from " ++ op)
         _ -> return ()
     return ()

intFormat :: String -> String
intFormat ('.':_) =
	[]
intFormat (x:xs) =
	x : intFormat xs

{- This function is similar to prepareBinopButton, but it's for
operators that take only one argument. -}

prepareUnopButton
  :: SR -> GladeXML -> String -> (Double -> Double) -> String -> IO ()
prepareUnopButton sr xml bname f op =
  do button <- xmlGetWidget xml castToButton bname
     widgetModifyBg button StateNormal $ Color 40000 40000 65535
     onClicked button $ do
       s <- readIORef sr
       case stack s of
         (x,x'):stack' ->
           do let r = f x
	      if (isInt s)
		then do		--Checks to see if in int mode, if so rounds result
			setStack sr (((read (show (round r)) :: Double),"Auto Gen from Inv"):stack')
			setDisplay sr (show r) "Auto Gen from Inv"		-- Should be generic but only 1 unop exists in calc
		else do
              		setStack sr ((r,"Auto Gen from Inv"):stack')
              		setDisplay sr (show (round r)) "Auto Gen from Inv"	-- Should be generic but only 1 unop exists in calc
         _ -> return ()
     return ()

-- Function to return a double as an int
doubleToInt :: Double -> Int
doubleToInt x =
	let x' = read (show (floor x))::Double
            str = (show x')
		in read (doubleToIntHelper str)::Int

doubleToIntHelper :: String -> String
doubleToIntHelper ('.':_) = []
doubleToIntHelper (x:xs) = x : doubleToIntHelper xs

{- This function sets up a button that is used to enter data into the
display, in particular digits and the decimal point. -}

prepareNumButton :: SR -> GladeXML -> String -> Char -> IO ()
prepareNumButton sr xml bname bchar =
  do button <- xmlGetWidget xml castToButton bname
     widgetModifyBg button StateNormal $ Color 65535 40000 40000
     onClicked button $ do
       s <- readIORef sr
       let newstr = displayString s ++ [bchar]
       let labelStr = displayLabel s
       setDisplay sr newstr labelStr
     return ()

-- Swaps the sign of the value at the top of the stack and returns the new stack
swapSign :: [(Double,String)] -> [(Double,String)]
swapSign ((x,y):xs) =
	((-x,y):xs)

-- Performs the Mode Function and adds it to the stack
doMod :: [(Double, String)] -> [(Double, String)]
doMod ((x,_):(y,_):xs) =
	let x' = doubleToInt x
	    y' = doubleToInt y
	    res = read (show (mod x' y'))::Double
	    in (res,"Auto Gen by Mod") : xs

-- Swaps first 2 values on the stack
exchFunc :: [(Double,String)] -> [(Double,String)]
exchFunc [] = []
exchFunc (x:[]) =
	(x:[])
exchFunc (x:y:ys) =
	(y:x:ys)

-- Calculates the rate into USD
toUSD :: Double -> Int -> Double
toUSD x 0 = (1/usd2gbp)*x 							
toUSD x 1 = (1/usd2cny)*x
toUSD x 2 = (1/usd2usd)*x
toUSD x 3 = (1/usd2eur)*x
toUSD x 4 = (1/usd2sgd)*x

-- Calculates the rate from USD
fromUSD :: Double -> Int -> Double
fromUSD x 0 = (usd2gbp)*x 							
fromUSD x 1 = (usd2cny)*x
fromUSD x 2 = (usd2usd)*x
fromUSD x 3 = (usd2eur)*x
fromUSD x 4 = (usd2sgd)*x
	
